<?php
/**
 * 数据源操作
 *
 * @author fefeding
 * @date 2014-12-21
 */
class Reportdata_model extends CI_Model
{
	


}
?>