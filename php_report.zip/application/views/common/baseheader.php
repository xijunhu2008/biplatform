<!DOCTYPE html>

<html lang="zh-CN">
<head>
<meta name="renderer" content="webkit">
<meta name="force-rendering" content="webkit">
<meta http-equiv="X-UA-Compatible" content="chrome=1,IE=edge">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="shortcut icon" href="<?php echo base_url('favicon.gif')?>" type="image/x-gif" />
<link rel="icon" href="<?php echo base_url('favicon.gif')?>" type="image/x-gif" />