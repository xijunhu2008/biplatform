    <!--[if lt IE 8]>
	<script type="text/javascript" src=".<?php echo base_url('static/js/json2.js')?>"></script>
	<![endif]-->
</head>
<body>